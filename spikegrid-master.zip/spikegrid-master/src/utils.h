void recursive_mkdir(const char* const dirname);
void* newdata(const void* const input,const unsigned int size);
void Hook_malloc();
long long int total_malloced;
