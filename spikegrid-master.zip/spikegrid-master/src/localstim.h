/// \file
#include "typedefs.h"
void ApplyLocalBoost(const Compute_float* geIn,const int xcenter,const int ycenter);
void RandomBlocking(Compute_float* geIn,const unsigned int time);
