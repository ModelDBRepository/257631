/// \file
typedef struct model model;
void FreeIfNotNull(void* v);
void CleanupModel(model* m);
