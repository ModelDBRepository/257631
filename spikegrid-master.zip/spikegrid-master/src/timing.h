void inittimer();
void timertick(const size_t timesteps,const size_t totaltimesteps);
