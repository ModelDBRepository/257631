/// \file
#include "typedefs.h"
typedef struct theta_parameters theta_parameters;
void dotheta(Compute_float* vin,const theta_parameters theta, const Compute_float time);
