/// \file
typedef struct sweepable sweepable;
void createyossarianfile (const char* const outfile,const sweepable sweep,const parameters L1, const parameters L2);
