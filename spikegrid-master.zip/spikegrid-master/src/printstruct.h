///\file
void printout_struct(const void* const invar,const char * const structname,const char* const dir,const int disp);
