#!/bin/bash
rm -rf job*
